﻿namespace Mandado_LockerSystem
{
    partial class Lockers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Lockers));
            this.locker1 = new System.Windows.Forms.PictureBox();
            this.locker2 = new System.Windows.Forms.PictureBox();
            this.locker3 = new System.Windows.Forms.PictureBox();
            this.locker4 = new System.Windows.Forms.PictureBox();
            this.locker5 = new System.Windows.Forms.PictureBox();
            this.locker6 = new System.Windows.Forms.PictureBox();
            this.locker7 = new System.Windows.Forms.PictureBox();
            this.locker8 = new System.Windows.Forms.PictureBox();
            this.locker9 = new System.Windows.Forms.PictureBox();
            this.locker20 = new System.Windows.Forms.PictureBox();
            this.locker10 = new System.Windows.Forms.PictureBox();
            this.locker19 = new System.Windows.Forms.PictureBox();
            this.locker11 = new System.Windows.Forms.PictureBox();
            this.locker18 = new System.Windows.Forms.PictureBox();
            this.locker12 = new System.Windows.Forms.PictureBox();
            this.locker17 = new System.Windows.Forms.PictureBox();
            this.locker13 = new System.Windows.Forms.PictureBox();
            this.locker16 = new System.Windows.Forms.PictureBox();
            this.locker14 = new System.Windows.Forms.PictureBox();
            this.locker15 = new System.Windows.Forms.PictureBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.logoutBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.locker1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker15)).BeginInit();
            this.SuspendLayout();
            // 
            // locker1
            // 
            this.locker1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.locker1.Image = global::Mandado_LockerSystem.Properties.Resources.AvailableLocker;
            this.locker1.Location = new System.Drawing.Point(65, 186);
            this.locker1.Name = "locker1";
            this.locker1.Size = new System.Drawing.Size(61, 123);
            this.locker1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.locker1.TabIndex = 20;
            this.locker1.TabStop = false;
            this.locker1.Click += new System.EventHandler(this.locker1_Click);
            // 
            // locker2
            // 
            this.locker2.Image = global::Mandado_LockerSystem.Properties.Resources.AvailableLocker;
            this.locker2.Location = new System.Drawing.Point(132, 186);
            this.locker2.Name = "locker2";
            this.locker2.Size = new System.Drawing.Size(61, 123);
            this.locker2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.locker2.TabIndex = 21;
            this.locker2.TabStop = false;
            this.locker2.Click += new System.EventHandler(this.locker2_Click);
            // 
            // locker3
            // 
            this.locker3.Image = ((System.Drawing.Image)(resources.GetObject("locker3.Image")));
            this.locker3.Location = new System.Drawing.Point(199, 186);
            this.locker3.Name = "locker3";
            this.locker3.Size = new System.Drawing.Size(61, 123);
            this.locker3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker3.TabIndex = 22;
            this.locker3.TabStop = false;
            this.locker3.Click += new System.EventHandler(this.locker3_Click);
            // 
            // locker4
            // 
            this.locker4.Image = ((System.Drawing.Image)(resources.GetObject("locker4.Image")));
            this.locker4.Location = new System.Drawing.Point(266, 186);
            this.locker4.Name = "locker4";
            this.locker4.Size = new System.Drawing.Size(61, 123);
            this.locker4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker4.TabIndex = 23;
            this.locker4.TabStop = false;
            this.locker4.Click += new System.EventHandler(this.locker4_Click);
            // 
            // locker5
            // 
            this.locker5.Image = ((System.Drawing.Image)(resources.GetObject("locker5.Image")));
            this.locker5.Location = new System.Drawing.Point(333, 186);
            this.locker5.Name = "locker5";
            this.locker5.Size = new System.Drawing.Size(61, 123);
            this.locker5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker5.TabIndex = 24;
            this.locker5.TabStop = false;
            this.locker5.Click += new System.EventHandler(this.locker5_Click);
            // 
            // locker6
            // 
            this.locker6.Image = ((System.Drawing.Image)(resources.GetObject("locker6.Image")));
            this.locker6.Location = new System.Drawing.Point(400, 186);
            this.locker6.Name = "locker6";
            this.locker6.Size = new System.Drawing.Size(61, 123);
            this.locker6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker6.TabIndex = 25;
            this.locker6.TabStop = false;
            this.locker6.Click += new System.EventHandler(this.locker6_Click);
            // 
            // locker7
            // 
            this.locker7.Image = ((System.Drawing.Image)(resources.GetObject("locker7.Image")));
            this.locker7.Location = new System.Drawing.Point(467, 186);
            this.locker7.Name = "locker7";
            this.locker7.Size = new System.Drawing.Size(61, 123);
            this.locker7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker7.TabIndex = 26;
            this.locker7.TabStop = false;
            this.locker7.Click += new System.EventHandler(this.locker7_Click);
            // 
            // locker8
            // 
            this.locker8.Image = ((System.Drawing.Image)(resources.GetObject("locker8.Image")));
            this.locker8.Location = new System.Drawing.Point(534, 186);
            this.locker8.Name = "locker8";
            this.locker8.Size = new System.Drawing.Size(61, 123);
            this.locker8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker8.TabIndex = 27;
            this.locker8.TabStop = false;
            this.locker8.Click += new System.EventHandler(this.locker8_Click);
            // 
            // locker9
            // 
            this.locker9.Image = ((System.Drawing.Image)(resources.GetObject("locker9.Image")));
            this.locker9.Location = new System.Drawing.Point(601, 186);
            this.locker9.Name = "locker9";
            this.locker9.Size = new System.Drawing.Size(61, 123);
            this.locker9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker9.TabIndex = 28;
            this.locker9.TabStop = false;
            this.locker9.Click += new System.EventHandler(this.locker9_Click);
            // 
            // locker20
            // 
            this.locker20.Image = ((System.Drawing.Image)(resources.GetObject("locker20.Image")));
            this.locker20.Location = new System.Drawing.Point(668, 315);
            this.locker20.Name = "locker20";
            this.locker20.Size = new System.Drawing.Size(61, 123);
            this.locker20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker20.TabIndex = 39;
            this.locker20.TabStop = false;
            this.locker20.Click += new System.EventHandler(this.locker20_Click);
            // 
            // locker10
            // 
            this.locker10.Image = ((System.Drawing.Image)(resources.GetObject("locker10.Image")));
            this.locker10.Location = new System.Drawing.Point(668, 186);
            this.locker10.Name = "locker10";
            this.locker10.Size = new System.Drawing.Size(61, 123);
            this.locker10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker10.TabIndex = 29;
            this.locker10.TabStop = false;
            this.locker10.Click += new System.EventHandler(this.locker10_Click);
            // 
            // locker19
            // 
            this.locker19.Image = ((System.Drawing.Image)(resources.GetObject("locker19.Image")));
            this.locker19.Location = new System.Drawing.Point(601, 315);
            this.locker19.Name = "locker19";
            this.locker19.Size = new System.Drawing.Size(61, 123);
            this.locker19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker19.TabIndex = 38;
            this.locker19.TabStop = false;
            this.locker19.Click += new System.EventHandler(this.locker19_Click);
            // 
            // locker11
            // 
            this.locker11.Image = ((System.Drawing.Image)(resources.GetObject("locker11.Image")));
            this.locker11.Location = new System.Drawing.Point(65, 315);
            this.locker11.Name = "locker11";
            this.locker11.Size = new System.Drawing.Size(61, 123);
            this.locker11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker11.TabIndex = 30;
            this.locker11.TabStop = false;
            this.locker11.Click += new System.EventHandler(this.locker11_Click);
            // 
            // locker18
            // 
            this.locker18.Image = ((System.Drawing.Image)(resources.GetObject("locker18.Image")));
            this.locker18.Location = new System.Drawing.Point(534, 315);
            this.locker18.Name = "locker18";
            this.locker18.Size = new System.Drawing.Size(61, 123);
            this.locker18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker18.TabIndex = 37;
            this.locker18.TabStop = false;
            this.locker18.Click += new System.EventHandler(this.locker18_Click);
            // 
            // locker12
            // 
            this.locker12.Image = ((System.Drawing.Image)(resources.GetObject("locker12.Image")));
            this.locker12.Location = new System.Drawing.Point(132, 315);
            this.locker12.Name = "locker12";
            this.locker12.Size = new System.Drawing.Size(61, 123);
            this.locker12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker12.TabIndex = 31;
            this.locker12.TabStop = false;
            this.locker12.Click += new System.EventHandler(this.locker12_Click);
            // 
            // locker17
            // 
            this.locker17.Image = ((System.Drawing.Image)(resources.GetObject("locker17.Image")));
            this.locker17.Location = new System.Drawing.Point(467, 315);
            this.locker17.Name = "locker17";
            this.locker17.Size = new System.Drawing.Size(61, 123);
            this.locker17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker17.TabIndex = 36;
            this.locker17.TabStop = false;
            this.locker17.Click += new System.EventHandler(this.locker17_Click);
            // 
            // locker13
            // 
            this.locker13.Image = ((System.Drawing.Image)(resources.GetObject("locker13.Image")));
            this.locker13.Location = new System.Drawing.Point(199, 315);
            this.locker13.Name = "locker13";
            this.locker13.Size = new System.Drawing.Size(61, 123);
            this.locker13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker13.TabIndex = 32;
            this.locker13.TabStop = false;
            this.locker13.Click += new System.EventHandler(this.locker13_Click);
            // 
            // locker16
            // 
            this.locker16.Image = ((System.Drawing.Image)(resources.GetObject("locker16.Image")));
            this.locker16.Location = new System.Drawing.Point(400, 315);
            this.locker16.Name = "locker16";
            this.locker16.Size = new System.Drawing.Size(61, 123);
            this.locker16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker16.TabIndex = 35;
            this.locker16.TabStop = false;
            this.locker16.Click += new System.EventHandler(this.locker16_Click);
            // 
            // locker14
            // 
            this.locker14.Image = ((System.Drawing.Image)(resources.GetObject("locker14.Image")));
            this.locker14.Location = new System.Drawing.Point(266, 315);
            this.locker14.Name = "locker14";
            this.locker14.Size = new System.Drawing.Size(61, 123);
            this.locker14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker14.TabIndex = 33;
            this.locker14.TabStop = false;
            this.locker14.Click += new System.EventHandler(this.locker14_Click);
            // 
            // locker15
            // 
            this.locker15.Image = ((System.Drawing.Image)(resources.GetObject("locker15.Image")));
            this.locker15.Location = new System.Drawing.Point(333, 315);
            this.locker15.Name = "locker15";
            this.locker15.Size = new System.Drawing.Size(61, 123);
            this.locker15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.locker15.TabIndex = 34;
            this.locker15.TabStop = false;
            this.locker15.Click += new System.EventHandler(this.locker15_Click);
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.BackColor = System.Drawing.Color.Transparent;
            this.nameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.Location = new System.Drawing.Point(184, 87);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(86, 31);
            this.nameLabel.TabIndex = 46;
            this.nameLabel.Text = "Name";
            this.nameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(59, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 31);
            this.label2.TabIndex = 45;
            this.label2.Text = "Login As";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(260, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(268, 41);
            this.label1.TabIndex = 44;
            this.label1.Text = "Available Lockers";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(239)))), ((int)(((byte)(234)))));
            this.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExit.Location = new System.Drawing.Point(761, 0);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(39, 36);
            this.btnExit.TabIndex = 43;
            this.btnExit.Text = "X";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // logoutBtn
            // 
            this.logoutBtn.BackColor = System.Drawing.Color.White;
            this.logoutBtn.FlatAppearance.BorderSize = 0;
            this.logoutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.logoutBtn.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutBtn.ForeColor = System.Drawing.Color.RoyalBlue;
            this.logoutBtn.Location = new System.Drawing.Point(617, 87);
            this.logoutBtn.Name = "logoutBtn";
            this.logoutBtn.Size = new System.Drawing.Size(127, 39);
            this.logoutBtn.TabIndex = 47;
            this.logoutBtn.Text = "Logout";
            this.logoutBtn.UseVisualStyleBackColor = false;
            this.logoutBtn.Click += new System.EventHandler(this.logoutBtn_Click);
            // 
            // Lockers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Mandado_LockerSystem.Properties.Resources._3;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 559);
            this.Controls.Add(this.logoutBtn);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.locker1);
            this.Controls.Add(this.locker2);
            this.Controls.Add(this.locker3);
            this.Controls.Add(this.locker4);
            this.Controls.Add(this.locker5);
            this.Controls.Add(this.locker6);
            this.Controls.Add(this.locker7);
            this.Controls.Add(this.locker8);
            this.Controls.Add(this.locker9);
            this.Controls.Add(this.locker20);
            this.Controls.Add(this.locker10);
            this.Controls.Add(this.locker19);
            this.Controls.Add(this.locker11);
            this.Controls.Add(this.locker18);
            this.Controls.Add(this.locker12);
            this.Controls.Add(this.locker17);
            this.Controls.Add(this.locker13);
            this.Controls.Add(this.locker16);
            this.Controls.Add(this.locker14);
            this.Controls.Add(this.locker15);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Lockers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lockers";
            ((System.ComponentModel.ISupportInitialize)(this.locker1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locker15)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox locker1;
        private System.Windows.Forms.PictureBox locker2;
        private System.Windows.Forms.PictureBox locker3;
        private System.Windows.Forms.PictureBox locker4;
        private System.Windows.Forms.PictureBox locker5;
        private System.Windows.Forms.PictureBox locker6;
        private System.Windows.Forms.PictureBox locker7;
        private System.Windows.Forms.PictureBox locker8;
        private System.Windows.Forms.PictureBox locker9;
        private System.Windows.Forms.PictureBox locker20;
        private System.Windows.Forms.PictureBox locker10;
        private System.Windows.Forms.PictureBox locker19;
        private System.Windows.Forms.PictureBox locker11;
        private System.Windows.Forms.PictureBox locker18;
        private System.Windows.Forms.PictureBox locker12;
        private System.Windows.Forms.PictureBox locker17;
        private System.Windows.Forms.PictureBox locker13;
        private System.Windows.Forms.PictureBox locker16;
        private System.Windows.Forms.PictureBox locker14;
        private System.Windows.Forms.PictureBox locker15;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button logoutBtn;
    }
}